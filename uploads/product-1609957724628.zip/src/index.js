var bodyParser = require("body-parser");
var app = require("./server");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.get("/", function (req, res) {
  res.send("Hello Player");
});

// Listen on port 8080
var listener = app.listen(process.env.PORT || 8080, function () {
  console.log("Listening on port " + listener.address().port);
});

const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
const routes = require("./routes/routes.js");

app.use(bodyParser());
app.use(cors());
app.post("/", routes);

module.exports = app;

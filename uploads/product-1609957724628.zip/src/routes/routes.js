const express = require("express");
const Router = express.Router();
const chapterLists = require("./data")
const Bible = require('../data/bibleClass')

const Data = new Bible()

Router.post("/chapters", function (req, res, next) {
  let book = req.body.book;
  let chapters = Data.getChaptersQuery(book);
  res.status(200).json(chapters)
});
Router.post("/verses", function (req, res, next) {
  let query = req.body;
  let book = query.book;
  let chapter = query.chapter;
let verses = Data.getNUmberOfVersesQuery(book, chapter)
res.statu(200).json(verses)
});
Router.post("/specific", function (req, res, next) {
let {book, chapter, verse} = req.body
let verseText = Data.getSpecificVerse(book, chapter, verse)
return res.status.json(verseText)
})

export default Router;
